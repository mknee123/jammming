This is project with Codeacademy.

It was fun but unfortunately it does not work properly yet. I can't seem to figure out how to get the search functionality to work. Hoping for some advice and guidance.
